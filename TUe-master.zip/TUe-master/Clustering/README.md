k-means clustering (soft/hard)
