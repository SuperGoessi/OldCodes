LinearRegression in House Price Predict
Importance: data cleaning and feature selection
