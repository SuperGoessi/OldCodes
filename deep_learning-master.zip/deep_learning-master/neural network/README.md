new version for Neural network
