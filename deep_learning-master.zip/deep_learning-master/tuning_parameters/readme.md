tuning some parameters for NN
