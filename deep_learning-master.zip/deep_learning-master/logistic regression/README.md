logistic regression model
