# Algorithm
Basic algorithm
