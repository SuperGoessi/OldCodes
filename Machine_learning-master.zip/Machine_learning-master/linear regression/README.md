linear regression for machine learning
