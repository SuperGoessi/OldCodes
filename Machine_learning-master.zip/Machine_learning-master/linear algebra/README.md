basic linear algebra
in Python
