simply work through the whole process
