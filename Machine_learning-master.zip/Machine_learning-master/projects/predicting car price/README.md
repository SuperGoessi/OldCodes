 k-nearest neighbors algorithm
 practice the machine learning workflow to predict a car's market price using its attributes
