simple calculus for machine_learning
