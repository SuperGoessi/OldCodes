# mechine-learning
learn mechine learning in Python
As I run futher in this way, I found that math plays an important role in mechine learning
Maybe I need to review advanced math again...
on my ladygaga
