learn about decision trees
